
import React from 'react';
import CountryApp from './components/CountryApp';
import './App.scss';
const App = () => {
  return (
    <div className="App">
      <CountryApp />
    </div>
  );
};
 
export default App;
 

